amostras_path="/home/glerm/fono/fonoaudiologia/amostras_ruins/"
