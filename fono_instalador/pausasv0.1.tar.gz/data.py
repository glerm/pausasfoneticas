Estrutura=[]
