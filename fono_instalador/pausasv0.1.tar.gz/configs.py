# -*- coding: utf-8 -*-

import os
from amostra_dir import *

homedir = os.path.expanduser('~')



# importante: nao esquecer de colocar a barra no fim exemplo: /home/user/amostras/
PYPATH= homedir+'/pausasv0.1/'
ROOTpath = amostras_path
CSVpath = homedir+'/pausasv0.1/csv/'

